
import { useState } from 'react';

export function Tabs({ children, defaultValue, className }) {
  const [value, setValue] = useState(defaultValue);
  return (
    <div className={className}>
      {React.Children.map(children, child => {
        if (child.type.displayName === 'TabsList') {
          return React.cloneElement(child, { value, setValue });
        }
        if (child.type.displayName === 'TabsContent') {
          return child.props.value === value ? child : null;
        }
        return child;
      })}
    </div>
  );
}
Tabs.displayName = 'Tabs';

export function TabsList({ children, value, setValue, className }) {
  return (
    <div className={className}>
      {React.Children.map(children, child => {
        if (child.type.displayName === 'TabsTrigger') {
          return React.cloneElement(child, { isActive: child.props.value === value, setValue });
        }
        return child;
      })}
    </div>
  );
}
TabsList.displayName = 'TabsList';

export function TabsTrigger({ value, isActive, setValue, children, className }) {
  return (
    <button
      className={`${className} px-4 py-2 ${isActive ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
      onClick={() => setValue(value)}
    >
      {children}
    </button>
  );
}
TabsTrigger.displayName = 'TabsTrigger';

export function TabsContent({ children, value }) {
  return <div>{children}</div>;
}
TabsContent.displayName = 'TabsContent';
