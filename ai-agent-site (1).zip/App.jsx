import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

const knowledgeBase = [
  {
    question: "ما هي ساعات العمل؟",
    answer: "ساعات العمل من الأحد إلى الخميس، من 9 صباحًا حتى 5 مساءً."
  },
  {
    question: "هل يوجد توصيل؟",
    answer: "نعم، نقدم خدمة التوصيل لجميع مناطق المملكة."
  },
  {
    question: "ما هي سياسة الاسترجاع؟",
    answer: "يمكنك استرجاع المنتج خلال 7 أيام من الاستلام بشرط أن يكون بحالته الأصلية."
  },
  {
    question: "هل يمكنني الدفع عند الاستلام؟",
    answer: "نعم، الدفع عند الاستلام متاح للطلبات داخل المدينة فقط."
  },
  {
    question: "كم مدة التوصيل؟",
    answer: "مدة التوصيل تتراوح من 2 إلى 5 أيام عمل حسب موقع العميل."
  },
  {
    question: "هل المنتجات أصلية؟",
    answer: "نعم، جميع منتجاتنا أصلية ومضمونة."
  }
];

export default function AIAgentPage() {
  const [language, setLanguage] = useState("ar");
  const [input, setInput] = useState("");
  const [response, setResponse] = useState("");
  const [loading, setLoading] = useState(false);

  const labels = {
    ar: {
      smartAssistant: "المساعد الذكي",
      advisor: "المستشار",
      writer: "وكيل الكتابة",
      executor: "وكيل تنفيذ المهام",
      support: "دعم العملاء",
      inputPlaceholder: "اكتب هنا...",
      send: "إرسال",
      changeLang: "English",
      notFound: "عذرًا، لم أتمكن من العثور على إجابة لهذا السؤال."
    },
    en: {
      smartAssistant: "Smart Assistant",
      advisor: "Advisor",
      writer: "Writing Agent",
      executor: "Task Executor",
      support: "Customer Support",
      inputPlaceholder: "Type here...",
      send: "Send",
      changeLang: "العربية",
      notFound: "Sorry, I couldn't find an answer to that question."
    }
  };

  const t = labels[language];

  const queryOpenAI = async (systemPrompt) => {
    setLoading(true);
    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer YOUR_OPENAI_API_KEY`
        },
        body: JSON.stringify({
          model: "gpt-4",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: input }
          ]
        })
      });
      const data = await res.json();
      const result = data.choices?.[0]?.message?.content || t.notFound;
      setResponse(result);
    } catch (error) {
      setResponse(language === "ar" ? "حدث خطأ أثناء الاتصال بخدمة الذكاء الصناعي." : "An error occurred while contacting the AI service.");
    } finally {
      setLoading(false);
    }
  };

  const handleSupportQuery = () => {
    const match = knowledgeBase.find(entry => input.includes(entry.question));
    setResponse(match ? match.answer : t.notFound);
  };

  const handleAdvisorQuery = () => {
    queryOpenAI(language === "ar"
      ? "أنت مستشار ذكي متخصص في تقديم نصائح عملية."
      : "You are an intelligent advisor that gives practical suggestions.");
  };

  const handleWriterQuery = () => {
    queryOpenAI(language === "ar"
      ? "أنت وكيل كتابة ذكي يساعد المستخدم في صياغة المحتوى بجودة عالية."
      : "You are a writing agent that helps the user craft high-quality content.");
  };

  const handleExecutorQuery = () => {
    queryOpenAI(language === "ar"
      ? "أنت وكيل تنفيذ مهام يساعد المستخدم على تنفيذ المهام اليومية بشكل فعال."
      : "You are a task executor that helps the user accomplish tasks efficiently.");
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">AI Agent</h1>
        <Button onClick={() => setLanguage(language === "ar" ? "en" : "ar")}>{t.changeLang}</Button>
      </div>
      <Tabs defaultValue="smart" className="w-full">
        <TabsList className="grid grid-cols-5">
          <TabsTrigger value="smart">{t.smartAssistant}</TabsTrigger>
          <TabsTrigger value="advisor">{t.advisor}</TabsTrigger>
          <TabsTrigger value="writer">{t.writer}</TabsTrigger>
          <TabsTrigger value="executor">{t.executor}</TabsTrigger>
          <TabsTrigger value="support">{t.support}</TabsTrigger>
        </TabsList>

        {Object.entries({
          smart: t.smartAssistant,
          advisor: t.advisor,
          writer: t.writer,
          executor: t.executor,
          support: t.support
        }).map(([key, label]) => (
          <TabsContent value={key} key={key}>
            <Card className="mt-4">
              <CardContent className="space-y-4 p-4">
                <h2 className="text-xl font-semibold">{label}</h2>
                <Textarea
                  placeholder={t.inputPlaceholder}
                  className="min-h-[120px]"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                />
                {response && (
                  <div className="bg-gray-100 p-3 rounded text-sm border whitespace-pre-wrap">{response}</div>
                )}
                <Button
                  onClick={
                    key === "support"
                      ? handleSupportQuery
                      : key === "advisor"
                      ? handleAdvisorQuery
                      : key === "writer"
                      ? handleWriterQuery
                      : key === "executor"
                      ? handleExecutorQuery
                      : () => alert("لم يتم ربط هذا الوكيل بعد")
                  }
                  disabled={loading}
                >
                  {loading ? "..." : t.send}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
